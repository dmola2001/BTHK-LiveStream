
using System;
using System.Collections.Generic;
using MediaBrowser.Common.Plugins;
using MediaBrowser.Model.Plugins;
using MediaBrowser.Model.Serialization;

namespace Jellyfin.Plugin.DirectInputLive;

public class Plugin : BasePlugin<PluginConfiguration>, IHasWebPages
{
    public Plugin(IJsonSerializer json, IApplicationPaths appPaths) : base(json, appPaths) { }

    public override string Name => "Direct Input Live";
    public override string Description => "Stream Windows DirectShow (dshow) inputs (capture cards/cameras + audio) to Jellyfin Live TV via FFmpeg.";
    public override Guid Id => new Guid("0ac7a7f5-9b9a-4d1c-8a8f-aaaaaaaaaaaa");

    public IEnumerable<PluginPageInfo> GetPages() => new[]
    {
        new PluginPageInfo
        {
            Name = "config",
            EmbeddedResourcePath = GetType().Namespace + ".Web.config.html"
        }
    };
}
