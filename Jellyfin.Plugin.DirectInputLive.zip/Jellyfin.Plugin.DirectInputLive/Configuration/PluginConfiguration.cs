
using System.Collections.Generic;
using MediaBrowser.Model.Plugins;

namespace Jellyfin.Plugin.DirectInputLive;

public class PluginConfiguration : BasePluginConfiguration
{
    public List<ChannelConfig> Channels { get; set; } = new();

    public string FFmpegPath { get; set; } = @"C:\ffmpeg\bin\ffmpeg.exe"; // Adjust to your path
}

public class ChannelConfig
{
    public string Id { get; set; } = "cam1";
    public string Name { get; set; } = "Camera 1";
    public string Platform { get; set; } = "Windows";
    public InputConfig Input { get; set; } = new();
    public FFmpegConfig FFmpeg { get; set; } = new();
    public OutputConfig Output { get; set; } = new();
}

public class InputConfig
{
    public string Format { get; set; } = "dshow";
    public string Video { get; set; } = "USB3.0 UHD";
    public string Audio { get; set; } = "Digital Audio Interface (USB3.0 Audio)";
}

public class FFmpegConfig
{
    public string VideoCodec { get; set; } = "libx264";
    public string AudioCodec { get; set; } = "aac";
    public string Preset { get; set; } = "veryfast";
    public int CRF { get; set; } = 23;
    public string MaxBitrate { get; set; } = "4000k";
    public string Tune { get; set; } = "zerolatency";
    public string Filters { get; set; } = "scale=1280:-1,fps=30";
    public string ExtraArgs { get; set; } = "";
}

public class OutputConfig
{
    public string Protocol { get; set; } = "ts"; // or "hls"
}
