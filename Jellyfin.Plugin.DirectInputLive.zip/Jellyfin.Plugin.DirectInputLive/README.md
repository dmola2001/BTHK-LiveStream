
# Jellyfin.Plugin.DirectInputLive

إضافة بسيطة للبث المباشر من مداخل Windows (DirectShow) إلى Jellyfin كقنوات Live TV عبر FFmpeg.

## التثبيت السريع (للتجربة)
1) ضع مسار FFmpeg في إعدادات الإضافة (افتراضياً `C:\ffmpeg\bin\ffmpeg.exe`).
2) أضف قنواتك من صفحة الإعدادات (الاسم + أجهزة dshow).
3) في Jellyfin: **Dashboard → Live TV → Tuner Devices → + M3U** وأضف:
   `http://YOUR_JELLYFIN/Plugins/DirectInputLive/live.m3u`
4) شغّل القنوات من تبويب Live TV.

> ملاحظة: هذا مشروع بداية وقد يحتاج مواءمة إصدارات الحزم مع إصدار Jellyfin لديك.
