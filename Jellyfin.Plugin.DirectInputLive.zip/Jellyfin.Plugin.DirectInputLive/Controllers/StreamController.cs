
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading;
using System.Threading.Tasks;
using System.IO;

namespace Jellyfin.Plugin.DirectInputLive.Controllers;

[ApiController]
[Route("Plugins/DirectInputLive")]
public class StreamController : ControllerBase
{
    private readonly ILogger<StreamController> _logger;
    private readonly Services.FFmpegProcessManager _ffmpeg;

    public StreamController(ILogger<StreamController> logger)
    {
        _logger = logger;
        _ffmpeg = new Services.FFmpegProcessManager();
    }

    [HttpGet("stream/{channelId}.ts")]
    public async Task<IActionResult> StreamTs(string channelId, CancellationToken ct)
    {
        var cfg = Plugin.Instance?.Configuration ?? new PluginConfiguration();
        var ch = cfg.Channels.Find(c => c.Id == channelId);
        if (ch is null) return NotFound();

        var args = Services.FFmpegArgsBuilder.ForChannel(cfg.FFmpegPath, ch, Services.OutputKind.Ts, GetClientUserAgent());
        var proc = _ffmpeg.StartProcess(args);

        Response.ContentType = "video/MP2T";
        await proc.StandardError.BaseStream.CopyToAsync(Stream.Null, ct); // consume logs
        await proc.StandardOutput.BaseStream.CopyToAsync(Response.Body, ct);
        await proc.WaitForExitAsync(ct);
        return new EmptyResult();
    }

    [HttpGet("stream/{channelId}.m3u8")]
    public IActionResult StreamHls(string channelId)
    {
        var cfg = Plugin.Instance?.Configuration ?? new PluginConfiguration();
        var ch = cfg.Channels.Find(c => c.Id == channelId);
        if (ch is null) return NotFound();

        var args = Services.FFmpegArgsBuilder.ForChannel(cfg.FFmpegPath, ch, Services.OutputKind.Hls, GetClientUserAgent());
        _ffmpeg.StartDetached(args); // writes to temp folder
        var url = $"{Request.Scheme}://{Request.Host}/Plugins/DirectInputLive/hls/{channelId}/index.m3u8";
        return Redirect(url);
    }

    [HttpGet("hls/{channelId}/{*file}")]
    public IActionResult HlsFiles(string channelId, string file = "index.m3u8")
    {
        var path = Services.FFmpegArgsBuilder.HlsPathForChannel(channelId);
        var full = System.IO.Path.Combine(path, file ?? "index.m3u8");
        if (!System.IO.File.Exists(full)) return NotFound();
        var mime = full.EndsWith(".m3u8") ? "application/x-mpegURL" : "video/MP2T";
        return PhysicalFile(full, mime);
    }

    private string GetClientUserAgent() => Request.Headers["User-Agent"].ToString() ?? "";
}
