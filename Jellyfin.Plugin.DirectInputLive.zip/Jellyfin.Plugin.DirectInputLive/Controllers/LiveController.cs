
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Linq;
using System.Text;

namespace Jellyfin.Plugin.DirectInputLive.Controllers;

[ApiController]
[Route("Plugins/DirectInputLive")]
public class LiveController : ControllerBase
{
    private readonly ILogger<LiveController> _logger;

    public LiveController(ILogger<LiveController> logger)
    {
        _logger = logger;
    }

    [HttpGet("live.m3u")]
    public IActionResult M3u()
    {
        var cfg = Plugin.Instance?.Configuration ?? new PluginConfiguration();
        var sb = new StringBuilder();
        sb.AppendLine("#EXTM3U");
        foreach (var ch in cfg.Channels)
        {
            sb.AppendLine($"#EXTINF:-1 tvg-id=\"{ch.Id}\" group-title=\"Direct Inputs\",{ch.Name}");
            var ext = ch.Output.Protocol == "hls" ? "m3u8" : "ts";
            sb.AppendLine($"{Request.Scheme}://{Request.Host}/Plugins/DirectInputLive/stream/{ch.Id}.{ext}");
        }
        return Content(sb.ToString(), "application/x-mpegURL", Encoding.UTF8);
    }
}
