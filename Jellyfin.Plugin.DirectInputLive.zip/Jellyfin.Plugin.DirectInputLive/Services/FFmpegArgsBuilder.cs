
using System;
using System.IO;
using System.Text;

namespace Jellyfin.Plugin.DirectInputLive.Services;

public enum OutputKind { Ts, Hls }

public static class FFmpegArgsBuilder
{
    public static (string FileName, string Arguments) ForChannel(string ffmpegPath, ChannelConfig ch, OutputKind kind, string userAgent)
    {
        var file = string.IsNullOrWhiteSpace(ffmpegPath) ? "ffmpeg" : ffmpegPath;

        // Input
        var sb = new StringBuilder();
        if (ch.Input.Format == "dshow")
        {
            sb.Append($" -f dshow -rtbufsize 256M -i video=\"{ch.Input.Video}\"");
            if (!string.IsNullOrWhiteSpace(ch.Input.Audio))
                sb.Append($":audio=\"{ch.Input.Audio}\"");
        }
        else
        {
            // fallback: raw device name
            sb.Append($" -i \"{ch.Input.Video}\"");
        }

        // Encoding
        sb.Append($" -vf {ch.FFmpeg.Filters} -c:v {ch.FFmpeg.VideoCodec} -preset {ch.FFmpeg.Preset} -tune {ch.FFmpeg.Tune} -crf {ch.FFmpeg.CRF}");
        if (!string.IsNullOrWhiteSpace(ch.FFmpeg.MaxBitrate))
            sb.Append($" -maxrate {ch.FFmpeg.MaxBitrate} -bufsize {GuessBufSize(ch.FFmpeg.MaxBitrate)}");
        sb.Append($" -c:a {ch.FFmpeg.AudioCodec} -b:a 128k ");
        if (!string.IsNullOrWhiteSpace(ch.FFmpeg.ExtraArgs))
            sb.Append(" " + ch.FFmpeg.ExtraArgs.Trim() + " ");

        if (kind == OutputKind.Ts)
        {
            sb.Append(" -f mpegts -");
        }
        else
        {
            var dir = HlsPathForChannel(ch.Id);
            Directory.CreateDirectory(dir);
            var outPath = Path.Combine(dir, "index.m3u8");
            sb.Append($" -f hls -hls_time 2 -hls_list_size 6 -hls_flags delete_segments+split_by_time \"{outPath}\"");
        }

        return (file, sb.ToString());
    }

    public static string HlsPathForChannel(string channelId)
    {
        var baseDir = Path.Combine(Path.GetTempPath(), "DirectInputLive", channelId);
        return baseDir;
    }

    private static string GuessBufSize(string maxrate)
    {
        // crude: 2x maxrate
        try
        {
            var v = maxrate.Trim().ToLowerInvariant();
            if (v.EndsWith("k")) v = v[:-1];
            int kbps = int.Parse(v);
            return $"{kbps*2}k";
        }
        catch { return "8000k"; }
    }
}
